from setuptools import setup

setup(name='scv_dist',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['scv_dist'],
      author = 'Tolulope Ayemobola',
      author_email = 'ayemobolatolulope@gmail.com',
      zip_safe=False)
